package com.aveson.admin;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    int BG=Color.rgb(4,6,16),SUR=Color.rgb(13,17,32),SUR2=Color.rgb(22,27,48);
    int PURPLE=Color.rgb(139,92,246),BLUE=Color.rgb(56,189,248),WHITE=Color.rgb(248,249,255),MUTED=Color.rgb(158,168,198),GOLD=Color.rgb(251,191,36);

    int d(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    GradientDrawable bg(int c,int r,int s){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(d(r));if(s>0)g.setStroke(d(s),Color.rgb(53,58,86));return g;}
    TextView t(String s,float z,int c,boolean b){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);v.setTypeface(b?Typeface.DEFAULT_BOLD:Typeface.DEFAULT);v.setIncludeFontPadding(false);return v;}
    LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(d(20),d(18),d(20),d(16));l.setBackgroundColor(BG);return l;}
    LinearLayout.LayoutParams lp(int h,int top,int bot){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,d(h));p.setMargins(0,d(top),0,d(bot));return p;}

    EditText field(String h){EditText e=new EditText(this);e.setHint(h);e.setHintTextColor(MUTED);e.setTextColor(WHITE);e.setTextSize(19);e.setSingleLine(true);e.setPadding(d(16),0,d(16),0);e.setBackground(bg(SUR,18,1));return e;}

    // SIGN IN stays at 50dp.
    Button sign(String s,Runnable a){Button b=action(s,a);b.setBackground(bg(PURPLE,28,0));b.setLayoutParams(lp(50,8,10));return b;}
    // Other buttons are slightly larger: 58dp.
    Button action(String s,Runnable a){Button b=new Button(this);b.setText(s);b.setTextSize(14);b.setTextColor(WHITE);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setAllCaps(false);b.setPadding(d(12),0,d(12),0);b.setBackground(bg(SUR2,20,1));b.setOnClickListener(v->a.run());b.setLayoutParams(lp(58,5,7));return b;}
    Button back(Runnable a){Button b=action("← BACK",a);b.setGravity(Gravity.CENTER);b.setTextSize(12);b.setLayoutParams(new LinearLayout.LayoutParams(d(92),d(42)));b.setOnClickListener(v->a.run());return b;}
    Button primary(String s,Runnable a){Button b=action(s,a);b.setBackground(bg(PURPLE,20,0));return b;}

    public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);login();}

    void login(){
        LinearLayout r=col(),c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(0,d(28),0,d(20));
        TextView mark=t("A",48,WHITE,true);mark.setGravity(Gravity.CENTER);mark.setBackground(bg(SUR2,18,1));
        LinearLayout brand=new LinearLayout(this);brand.setGravity(Gravity.CENTER_VERTICAL);brand.addView(mark,new LinearLayout.LayoutParams(d(74),d(74)));
        TextView name=t("AVESON ADMIN",30,PURPLE,true);name.setGravity(Gravity.CENTER_VERTICAL);brand.addView(name,new LinearLayout.LayoutParams(0,d(74),1));
        c.addView(brand,lp(74,0,18));c.addView(t("Operations Center",28,WHITE,true),lp(40,0,4));
        c.addView(t("Private platform administration • owner / operations",15,MUTED,false),lp(36,0,28));
        EditText e=field("Admin email"),p=field("Password");p.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        c.addView(e,lp(68,0,8));c.addView(p,lp(68,0,14));
        c.addView(sign("SIGN IN",()->{if(!validAdminEmail(e.getText().toString())){toast("Enter a valid admin email");return;}if(!strongPassword(p.getText().toString())){toast("Password must be 8+ characters with letters and numbers");return;}dashboard();}));
        c.addView(t("PRIVATE • ADMIN ONLY • 2-STEP DEMO GATE",12,GOLD,true),lp(30,8,0));
        ScrollView s=new ScrollView(this);s.addView(c);r.addView(s,new LinearLayout.LayoutParams(-1,0,1));setContentView(r);
    }

    boolean validAdminEmail(String x){return x.matches("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");}
    boolean strongPassword(String x){boolean letter=false,digit=false;for(char ch:x.toCharArray()){if(Character.isLetter(ch))letter=true;if(Character.isDigit(ch))digit=true;}return x.length()>=8&&letter&&digit;}

    Button menuButton(){Button b=new Button(this);b.setText("≡");b.setTextSize(22);b.setTextColor(WHITE);b.setGravity(Gravity.CENTER);b.setPadding(0,0,0,0);b.setBackground(bg(SUR2,16,1));b.setOnClickListener(v->parameters());b.setLayoutParams(new LinearLayout.LayoutParams(d(46),d(42)));return b;}

    void header(LinearLayout r,String title,String sub,Runnable a){
        LinearLayout top=new LinearLayout(this);top.setOrientation(LinearLayout.HORIZONTAL);top.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(back(a),new LinearLayout.LayoutParams(d(92),d(42)));
        Space sp=new Space(this);top.addView(sp,new LinearLayout.LayoutParams(0,d(42),1));
        top.addView(menuButton(),new LinearLayout.LayoutParams(d(46),d(42)));
        r.addView(top,lp(42,0,12));
        r.addView(t("AVESON ADMIN",25,PURPLE,true),lp(34,0,3));
        r.addView(t(title,26,WHITE,true),lp(38,0,3));
        r.addView(t(sub,14,MUTED,false),lp(34,0,16));
    }

    void parameters(){
        LinearLayout r=col();
        r.addView(back(this::dashboard));
        r.addView(t("PARAMETERS",28,WHITE,true),lp(38,8,4));
        r.addView(t("Admin settings are kept here, separate from operations.",14,MUTED,false),lp(42,0,18));
        r.addView(primary("⚙ PLATFORM SETTINGS",()->tool("PLATFORM SETTINGS")));
        r.addView(primary("🔐 SECURITY & SESSIONS",()->tool("SECURITY & SESSIONS")));
        r.addView(primary("◎ NOTIFICATIONS",()->tool("NOTIFICATIONS")));
        r.addView(primary("◈ DEFAULT REVIEW RULES",()->tool("DEFAULT REVIEW RULES")));
        r.addView(primary("🌍 DISTRIBUTION PREFERENCES",()->tool("DISTRIBUTION PREFERENCES")));
        r.addView(action("BACK TO OPERATIONS",this::dashboard));
        setContentView(r);
    }

    LinearLayout metric(String a,String b,int color,Runnable run){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(d(16),d(15),d(16),d(15));c.setBackground(bg(SUR,20,0));c.setOnClickListener(v->run.run());c.addView(t(a,11,MUTED,true));c.addView(t(b,28,WHITE,true),lp(40,7,0));c.setLayoutParams(lp(92,5,7));return c;}

    LinearLayout grid(){LinearLayout g=new LinearLayout(this);g.setOrientation(LinearLayout.VERTICAL);return g;}

    Button tile(String icon,String title,String sub,Runnable a){
        Button b=new Button(this);
        b.setText(icon+"\n"+title+"\n"+sub);
        b.setTextSize(12); b.setTextColor(WHITE); b.setGravity(Gravity.CENTER);
        b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); b.setAllCaps(false);
        b.setPadding(d(6),d(5),d(6),d(5)); b.setBackground(bg(SUR,18,1));
        b.setOnClickListener(v->a.run());
        b.setLayoutParams(new LinearLayout.LayoutParams(0,d(108),1));
        return b;
    }

    void dashboard(){
        LinearLayout r=col();
        header(r,"Operations Center","Private platform control center.",this::login);
        ScrollView s=new ScrollView(this);
        LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);
        c.addView(t("OVERVIEW",11,MUTED,true),lp(24,0,7));

        LinearLayout row1=new LinearLayout(this);row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.setGravity(Gravity.CENTER);
        row1.addView(tile("◉","PENDING","7 reviews",this::queue));
        Space gap1=new Space(this);row1.addView(gap1,new LinearLayout.LayoutParams(d(8),d(108)));
        row1.addView(tile("◎","ARTISTS","128 accounts",this::artists));
        c.addView(row1,lp(108,0,8));

        LinearLayout row2=new LinearLayout(this);row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.addView(tile("↗","DISTRIBUTION","7 queued",()->tool("DISTRIBUTION QUEUE")));
        Space gap2=new Space(this);row2.addView(gap2,new LinearLayout.LayoutParams(d(8),d(108)));
        row2.addView(tile("◈","RIGHTS","3 cases",()->tool("RIGHTS & COPYRIGHT")));
        c.addView(row2,lp(108,0,16));

        c.addView(t("QUICK OPERATIONS",11,MUTED,true),lp(24,0,7));
        c.addView(primary("▣  RELEASE QUEUE",this::queue),lp(58,0,7));
        c.addView(primary("●  ARTISTS",this::artists),lp(58,0,7));
        c.addView(action("≡  MORE ADMIN TOOLS",this::more),lp(58,0,7));
        c.addView(t("AVESON ADMIN • OPERATIONS CENTER",11,MUTED,false),lp(24,10,8));
        s.addView(c);r.addView(s,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(r);
    }

    void queue(){LinearLayout r=col();header(r,"Release Queue","Review incoming artist releases.",this::dashboard);ScrollView s=new ScrollView(this);LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.addView(t("7 releases waiting for review",14,MUTED,true),lp(32,0,8));
        String[][] rows={{"Midnight Dreams","Test Artist","Pending Review"},{"Lost in Space","Aveson Test","Pending Review"},{"No Rules","New Artist","Changes Required"}};
        for(String[] x:rows){LinearLayout q=new LinearLayout(this);q.setOrientation(LinearLayout.VERTICAL);q.setPadding(d(16),d(14),d(16),d(14));q.setBackground(bg(SUR,20,0));q.addView(t(x[0],17,WHITE,true));q.addView(t(x[1]+" • "+x[2],13,MUTED,false),lp(24,7,5));q.addView(action("OPEN REVIEW",()->review(x[0])));c.addView(q,lp(150,5,8));}
        s.addView(c);r.addView(s,new LinearLayout.LayoutParams(-1,0,1));r.addView(action("BACK TO OPERATIONS",this::dashboard));setContentView(r);}

    void review(String rel){
        LinearLayout r=col();header(r,"Release Review",rel+" • review and release status.",this::queue);
        r.addView(t("FINAL REVIEW",11,MUTED,true),lp(22,0,3));
        r.addView(t(rel,24,WHITE,true),lp(34,0,12));
        r.addView(check("✓ AUDIO","WAV / FLAC master • technical quality check"));
        r.addView(check("✓ COVER","Square high-resolution artwork • AVESON standard"));
        r.addView(check("✓ METADATA","Title, artist, featuring, genre, language, release date"));
        r.addView(check("✓ RIGHTS","Ownership, contributors, copyright information"));
        r.addView(check("✓ CONTENT","Explicit / clean and content policy review"));
        r.addView(t("Choose the final decision for this submission.",13,MUTED,false),lp(42,8,10));
        r.addView(primary("APPROVE RELEASE",()->toast("Release approved ✓")));
        r.addView(action("REQUEST CHANGES",()->toast("Changes requested ✓")));
        r.addView(action("REJECT RELEASE",()->toast("Release rejected ✓")));
        r.addView(action("BACK TO QUEUE",this::queue));
        setContentView(r);
    }

    LinearLayout check(String title,String sub){
        LinearLayout q=new LinearLayout(this);q.setOrientation(LinearLayout.VERTICAL);q.setPadding(d(15),d(12),d(15),d(12));q.setBackground(bg(SUR,18,0));
        q.addView(t(title,15,WHITE,true));q.addView(t(sub,12,MUTED,false),lp(22,5,0));
        q.setLayoutParams(lp(68,4,5));return q;
    }


    void artists(){
        LinearLayout r=col();
        header(r,"Artists","Artist accounts and activity.",this::dashboard);
        ScrollView s=new ScrollView(this);
        LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);
        c.addView(t("128 artists • 124 active • 4 onboarding",14,MUTED,true),lp(32,0,8));
        String[][] a={{"Test Artist","12 releases • Active","test@artist.com"},{"Aveson Test","3 releases • Active","aveson@test.com"},{"New Artist","0 releases • Onboarding","new@artist.com"},{"Global Sound","8 releases • Active","global@sound.com"}};
        for(String[] x:a){
            LinearLayout q=new LinearLayout(this);q.setOrientation(LinearLayout.VERTICAL);q.setPadding(d(16),d(15),d(16),d(15));q.setBackground(bg(SUR,20,0));
            q.addView(t(x[0],17,WHITE,true));
            q.addView(t(x[1],13,MUTED,false),lp(24,7,3));
            q.addView(t(x[2],12,MUTED,false),lp(20,0,7));
            q.addView(action("OPEN ARTIST",()->artistDetail(x[0],x[1],x[2])));
            c.addView(q,lp(132,5,8));
        }
        s.addView(c);r.addView(s,new LinearLayout.LayoutParams(-1,0,1));
        r.addView(action("BACK TO OPERATIONS",this::dashboard));setContentView(r);
    }

    void artistDetail(String name,String stats,String email){
        LinearLayout r=col();header(r,"Artist Profile",name+" • account overview.",this::artists);
        r.addView(t("ARTIST",11,MUTED,true),lp(22,0,2));
        r.addView(t(name,26,WHITE,true),lp(38,0,3));
        r.addView(t(email,14,MUTED,false),lp(28,0,14));
        r.addView(metric("RELEASES",stats.split(" ")[0],PURPLE,()->toast("Release library opened")));
        r.addView(primary("OPEN RELEASES",()->queue()));
        r.addView(action("ACCOUNT STATUS",()->toast("Account: Active")));
        r.addView(action("CONTACT ARTIST",()->toast("Artist contact ready")));
        r.addView(action("BACK TO ARTISTS",this::artists));
        setContentView(r);
    }

    void more(){
        LinearLayout r=col();
        header(r,"Admin Operations","All private tools in one place.",this::dashboard);
        ScrollView s=new ScrollView(this);
        LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);
        c.addView(t("CONTROL CENTER",11,MUTED,true),lp(24,0,8));
        String[][] x={{"🌍","PLATFORMS","Distribution","PLATFORMS"},{"↗","DISTRIBUTION","Queue","DISTRIBUTION QUEUE"},{"◈","RIGHTS","Copyright","RIGHTS & COPYRIGHT"},{"$","ROYALTIES","Finance","ROYALTIES"},{"⚙","PARAMETERS","Settings","PLATFORM SETTINGS"},{"🔐","SECURITY","Audit log","SECURITY & AUDIT LOG"}};
        for(int i=0;i<x.length;i+=2){
            final int index = i;
            final String[] first = x[index];
            LinearLayout row=new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.addView(tile(first[0],first[1],first[2],()->tool(first[3])));
            Space sp=new Space(this);
            row.addView(sp,new LinearLayout.LayoutParams(d(8),d(108)));
            if(index+1<x.length){
                final String[] second = x[index+1];
                row.addView(tile(second[0],second[1],second[2],()->tool(second[3])));
            }
            c.addView(row,lp(108,0,8));
        }
        c.addView(action("←  BACK TO OPERATIONS",this::dashboard),lp(58,8,7));
        c.addView(action("LOG OUT",this::login),lp(58,0,7));
        s.addView(c);r.addView(s,new LinearLayout.LayoutParams(-1,0,1));setContentView(r);
    }

    void tool(String name){LinearLayout r=col();header(r,name,"AVESON private operations module.",this::more);r.addView(t("Module ready",20,WHITE,true),lp(32,0,8));r.addView(t("This Admin prototype is ready for backend/API integration.",14,MUTED,false),lp(70,0,12));r.addView(action("OPEN MODULE",()->toast(name+" opened")));r.addView(action("REVIEW SETTINGS",()->toast("Settings ready")));r.addView(action("BACK",this::more));setContentView(r);}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
